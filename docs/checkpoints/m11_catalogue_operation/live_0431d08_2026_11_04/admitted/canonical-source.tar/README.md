Prepared local Plan Package v2 and exact native graph sources.
Not approval, hosted publication, assignment or started athlete state.
Editable files separately retain drafts/history. Imported canonical sources are new local snapshots with unknown history.
Package hashes do not include all graph bytes; verify source-index.json and all members.
No owner/version/activation/publication receipt is fabricated.
